
var editElement = document.querySelector(".hjd")

function editprofile(element) {
    editElement.innerText ="[edit name]";
}


var toddElement1 = document.querySelector("#toddaccept")
var toddElement2 = document.querySelector("#todddecline")
var toddElement3 = document.querySelector("#todd")
var toddElement4 = document.querySelector("#ptodd")
var h22 = 2
var countElement = document.querySelector("#h22");

function connection(element) {
    toddElement1.remove();
    toddElement2.remove();
    toddElement3.remove();
    toddElement4.remove();
    h22--;
    countElement.innerText= h22

}
var toddElement1 = document.querySelector("#toddaccept")
var h222 = 418
var countElement2 = document.querySelector("#h222");

function connectionaccept(element) {
    toddElement1.remove();
    toddElement2.remove();
    toddElement3.remove();
    toddElement4.remove();
    h22--;
    countElement.innerText= h22 
    h222++;
    countElement2.innerText= h222;

}

var philElement1 = document.querySelector("#philaccept")
var philElement2 = document.querySelector("#phildecline")
var philElement3 = document.querySelector("#phil")
var philElement4 = document.querySelector("#pphil")
var h22 = 2
var countElement1 = document.querySelector("#h22");

function connection1(element) {
    philElement1.remove();
    philElement2.remove();
    philElement3.remove();
    philElement4.remove();
    h22--;
    countElement1.innerText= h22 
}

function connection1accept(element) {
    philElement1.remove();
    philElement2.remove();
    philElement3.remove();
    philElement4.remove();
    h22--;
    countElement.innerText= h22 
    h222++;
    countElement2.innerText= h222;

}


