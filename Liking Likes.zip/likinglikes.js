var count = 9
var countElement = document.querySelector("#count");

function add1(){
    count++;
    countElement.innerText = count + "like(s)";
}

var count2 = 12
var countElement2 = document.querySelector("#count2");

function add2(){
    count2++;
    countElement2.innerText = count2 + " like(s)";
}

var count3 = 9
var countElement3 = document.querySelector("#count3");

function add3(){
    count3++;
    countElement3.innerText = count3 + " like(s)";
}