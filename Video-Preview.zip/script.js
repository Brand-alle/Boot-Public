
function play(element) {
    element.play();
    element.muted();
}
function pause(element) {
    element.pause();
    element.muted();
}