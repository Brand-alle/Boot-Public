function hide(element) {
    element.remove();
}
function logout(element) {
    element.innerText="Logout";
}